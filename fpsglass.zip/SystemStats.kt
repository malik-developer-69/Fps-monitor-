package com.example.fpsglass

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/** Cheap, best-effort device readings. Anything the phone does not expose comes back as NaN / -1. */
class SystemStats(private val ctx: Context) {

    class Snapshot(
        val batTempC: Float,
        val batPct: Int,
        val charging: Boolean,
        val thermal: Int,
        val cpuTempC: Float,
        val ramPct: Int,
        val cpuGhz: Float,
        val pingMs: Int
    )

    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val mem = ActivityManager.MemoryInfo()
    private val batFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)

    private var tempPath: String? = null
    private var tempSearched = false
    private var freqPaths: List<String>? = null

    @Volatile var pingMs = -1
    private var pingExec: ScheduledExecutorService? = null

    fun read(): Snapshot {
        val i = ctx.registerReceiver(null, batFilter)
        val batTemp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val thermal = if (Build.VERSION.SDK_INT >= 29) pm.currentThermalStatus else 0

        am.getMemoryInfo(mem)
        val ram = if (mem.totalMem > 0) ((mem.totalMem - mem.availMem) * 100 / mem.totalMem).toInt() else -1

        return Snapshot(batTemp, pct, charging, thermal, readCpuTemp(), ram, readCpuGhz(), pingMs)
    }

    // ---- CPU / SoC temperature (many phones block this; then it is simply hidden) ----
    private fun readCpuTemp(): Float {
        if (!tempSearched) {
            tempSearched = true
            tempPath = findTempPath()
        }
        val p = tempPath ?: return Float.NaN
        val raw = readLine(p)?.trim()?.toFloatOrNull() ?: return Float.NaN
        return if (raw > 1000f) raw / 1000f else raw
    }

    private fun findTempPath(): String? {
        var fallback: String? = null
        for (z in 0..60) {
            val dir = "/sys/class/thermal/thermal_zone$z"
            val type = readLine("$dir/type")?.lowercase() ?: continue
            val raw = readLine("$dir/temp")?.trim()?.toFloatOrNull() ?: continue
            val c = if (raw > 1000f) raw / 1000f else raw
            if (c < 5f || c > 120f) continue
            if (type.contains("cpu") || type.contains("soc") || type.contains("tsens") ||
                type.contains("cluster") || type.contains("big") || type.contains("little")
            ) return "$dir/temp"
            if (fallback == null && !type.contains("batt") && !type.contains("usb") &&
                !type.contains("charg") && !type.contains("skin")
            ) fallback = "$dir/temp"
        }
        return fallback
    }

    // ---- CPU clock ----
    private fun readCpuGhz(): Float {
        if (freqPaths == null) {
            val ok = ArrayList<String>()
            for (n in 0..15) {
                val p = "/sys/devices/system/cpu/cpu$n/cpufreq/scaling_cur_freq"
                if (readLine(p) != null) ok.add(p)
            }
            freqPaths = ok
        }
        var best = 0f
        for (p in freqPaths!!) {
            val khz = readLine(p)?.trim()?.toFloatOrNull() ?: continue
            if (khz > best) best = khz
        }
        return if (best > 0f) best / 1_000_000f else Float.NaN
    }

    private fun readLine(path: String): String? = try {
        File(path).bufferedReader().use { it.readLine() }
    } catch (e: Exception) {
        null
    }

    // ---- Ping (TCP connect time to Cloudflare, every 3 s) ----
    fun startPing() {
        if (pingExec != null) return
        val e = Executors.newSingleThreadScheduledExecutor()
        pingExec = e
        e.scheduleWithFixedDelay({ pingMs = probe() }, 0, 3, TimeUnit.SECONDS)
    }

    fun stopPing() {
        pingExec?.shutdownNow()
        pingExec = null
        pingMs = -1
    }

    private fun probe(): Int = try {
        val t0 = System.nanoTime()
        Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
        ((System.nanoTime() - t0) / 1_000_000).toInt()
    } catch (e: Exception) {
        -1
    }
}
