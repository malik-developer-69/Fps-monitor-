package com.example.fpsglass

import android.content.Context
import android.content.SharedPreferences

object K {
    const val STYLE = "style"; const val LAYOUT = "layout"; const val FONT = "font"
    const val TINT = "tint"; const val TINT_A = "tint_a"
    const val BORDER = "border"; const val BORDER_W = "border_w"
    const val TEXT = "text"; const val COLOR_MODE = "color_mode"; const val ACCENT = "accent"
    const val GLOSS = "gloss"; const val RADIUS = "radius"; const val SCALE = "scale"
    const val FPS_SIZE = "fps_size"; const val OPACITY = "opacity"
    const val GRAPH = "graph"; const val GRAPH_STYLE = "graph_style"
    const val FRAME_TIME = "frame_time"; const val LOW = "low"
    const val BAT_TEMP = "bat_temp"; const val CPU_TEMP = "cpu_temp"; const val THERMAL = "thermal"
    const val BAT_PCT = "bat_pct"; const val RAM = "ram"; const val CPU_CLK = "cpu_clk"
    const val PING = "ping"; const val HZ = "hz"; const val JANK = "jank"
    const val SESSION = "session"; const val CLOCK = "clock"
    const val INTERVAL = "interval_i"; const val TARGET = "target_i"
    const val UNIT = "unit"; const val WARN = "warn"
    const val LOCK = "lock"; const val THROUGH = "through"; const val SNAP = "snap"
    const val COMPACT = "compact"; const val POS_X = "pos_x"; const val POS_Y = "pos_y"
}

/** All user-tweakable options, loaded from SharedPreferences. */
class Cfg {
    var style = 0
    var layout = 0
    var font = 0
    var tint = WHITE
    var tintAlpha = 26
    var border = WHITE
    var borderW = 12
    var textColor = WHITE
    var colorMode = 0
    var accent = DEF_ACCENT
    var gloss = true
    var radius = 22
    var scale = 100
    var fpsSize = 100
    var opacity = 100
    var showGraph = true
    var graphStyle = 0
    var showFrameTime = true
    var showLow = true
    var showBatTemp = true
    var showCpuTemp = true
    var showThermal = false
    var showBatPct = false
    var showRam = false
    var showCpuClk = false
    var showPing = false
    var showHz = false
    var showJank = false
    var showSession = false
    var showClock = false
    var intervalIdx = 1
    var targetIdx = 0
    var tempUnit = 0
    var warnTemp = 43
    var lock = false
    var touchThrough = false
    var snap = false
    var compact = false
    var posX = -1
    var posY = -1

    val interval: Int get() = INTERVALS[intervalIdx.coerceIn(0, INTERVALS.size - 1)]
    val target: Int get() = TARGETS[targetIdx.coerceIn(0, TARGETS.size - 1)]

    fun load(p: SharedPreferences) {
        style = p.getInt(K.STYLE, 0)
        layout = p.getInt(K.LAYOUT, 0)
        font = p.getInt(K.FONT, 0)
        tint = p.getInt(K.TINT, WHITE)
        tintAlpha = p.getInt(K.TINT_A, 26)
        border = p.getInt(K.BORDER, WHITE)
        borderW = p.getInt(K.BORDER_W, 12)
        textColor = p.getInt(K.TEXT, WHITE)
        colorMode = p.getInt(K.COLOR_MODE, 0)
        accent = p.getInt(K.ACCENT, DEF_ACCENT)
        gloss = p.getBoolean(K.GLOSS, true)
        radius = p.getInt(K.RADIUS, 22)
        scale = p.getInt(K.SCALE, 100)
        fpsSize = p.getInt(K.FPS_SIZE, 100)
        opacity = p.getInt(K.OPACITY, 100)
        showGraph = p.getBoolean(K.GRAPH, true)
        graphStyle = p.getInt(K.GRAPH_STYLE, 0)
        showFrameTime = p.getBoolean(K.FRAME_TIME, true)
        showLow = p.getBoolean(K.LOW, true)
        showBatTemp = p.getBoolean(K.BAT_TEMP, true)
        showCpuTemp = p.getBoolean(K.CPU_TEMP, true)
        showThermal = p.getBoolean(K.THERMAL, false)
        showBatPct = p.getBoolean(K.BAT_PCT, false)
        showRam = p.getBoolean(K.RAM, false)
        showCpuClk = p.getBoolean(K.CPU_CLK, false)
        showPing = p.getBoolean(K.PING, false)
        showHz = p.getBoolean(K.HZ, false)
        showJank = p.getBoolean(K.JANK, false)
        showSession = p.getBoolean(K.SESSION, false)
        showClock = p.getBoolean(K.CLOCK, false)
        intervalIdx = p.getInt(K.INTERVAL, 1)
        targetIdx = p.getInt(K.TARGET, 0)
        tempUnit = p.getInt(K.UNIT, 0)
        warnTemp = p.getInt(K.WARN, 43)
        lock = p.getBoolean(K.LOCK, false)
        touchThrough = p.getBoolean(K.THROUGH, false)
        snap = p.getBoolean(K.SNAP, false)
        compact = p.getBoolean(K.COMPACT, false)
        posX = p.getInt(K.POS_X, -1)
        posY = p.getInt(K.POS_Y, -1)
    }

    companion object {
        val WHITE: Int = 0xFFFFFFFF.toInt()
        val DEF_ACCENT: Int = 0xFF38BDF8.toInt()
        val INTERVALS = intArrayOf(250, 500, 1000)
        val TARGETS = intArrayOf(0, 30, 60, 90, 120, 144)
        fun prefs(c: Context): SharedPreferences =
            c.getSharedPreferences("fps_glass", Context.MODE_PRIVATE)
    }
}

object Themes {
    class T(
        val name: String, val style: Int, val tint: Int, val alpha: Int,
        val border: Int, val text: Int, val mode: Int, val accent: Int, val gloss: Boolean
    )

    private fun c(v: Long) = v.toInt()

    val all = listOf(
        T("Ice Glass", 0, c(0xFFFFFFFF), 26, c(0xFFFFFFFF), c(0xFFFFFFFF), 0, c(0xFF38BDF8), true),
        T("Cyber Neon", 1, c(0xFF0B1020), 70, c(0xFF00E5FF), c(0xFFE0F7FF), 1, c(0xFFFF3CAC), false),
        T("Midnight", 0, c(0xFF000000), 55, c(0xFFFFFFFF), c(0xFFFFFFFF), 0, c(0xFF38BDF8), true),
        T("Aurora", 0, c(0xFF7C3AED), 40, c(0xFFC4B5FD), c(0xFFFFFFFF), 1, c(0xFF5EEAD4), true),
        T("Sunset", 0, c(0xFFF97316), 38, c(0xFFFDE68A), c(0xFFFFFFFF), 1, c(0xFFFFE08A), true),
        T("Matrix", 2, c(0xFF001A06), 85, c(0xFF22C55E), c(0xFFB7F7C8), 1, c(0xFF22C55E), false),
        T("Rose", 0, c(0xFFEC4899), 36, c(0xFFFBCFE8), c(0xFFFFFFFF), 1, c(0xFFFFFFFF), true),
        T("Stealth", 3, c(0xFF000000), 0, c(0xFFFFFFFF), c(0xFFFFFFFF), 0, c(0xFF38BDF8), false)
    )

    fun apply(sp: SharedPreferences, i: Int) {
        val t = all[i]
        sp.edit()
            .putInt(K.STYLE, t.style)
            .putInt(K.TINT, t.tint)
            .putInt(K.TINT_A, t.alpha)
            .putInt(K.BORDER, t.border)
            .putInt(K.TEXT, t.text)
            .putInt(K.COLOR_MODE, t.mode)
            .putInt(K.ACCENT, t.accent)
            .putBoolean(K.GLOSS, t.gloss)
            .apply()
    }
}
