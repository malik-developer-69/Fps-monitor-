package com.example.fpsglass

import android.view.Choreographer
import kotlin.math.roundToInt

/**
 * Counts vsync frame callbacks and reports once per [windowMs].
 * Zero allocations per frame; one lambda call per report.
 */
class FpsMeter(
    private val windowMs: Long = 500L,
    private val onReport: (fps: Int, avgFrameMs: Float, onePercentLowFps: Int) -> Unit
) : Choreographer.FrameCallback {

    private val choreographer = Choreographer.getInstance()
    private var running = false
    private var lastNs = 0L
    private var windowStartNs = 0L
    private var intervals = 0
    private var worstMs = 0f

    fun start() {
        if (running) return
        running = true
        lastNs = 0L
        intervals = 0
        worstMs = 0f
        choreographer.postFrameCallback(this)
    }

    fun stop() {
        running = false
        choreographer.removeFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return

        if (lastNs == 0L) {
            windowStartNs = frameTimeNanos
        } else {
            val ms = (frameTimeNanos - lastNs) / 1_000_000f
            if (ms > worstMs) worstMs = ms
            intervals++
        }
        lastNs = frameTimeNanos

        val elapsedNs = frameTimeNanos - windowStartNs
        if (intervals > 0 && elapsedNs >= windowMs * 1_000_000L) {
            val fps = (intervals * 1_000_000_000.0 / elapsedNs).roundToInt()
            val avgMs = elapsedNs / intervals / 1_000_000f
            val low = if (worstMs > 0f) (1000f / worstMs).roundToInt() else fps
            onReport(fps, avgMs, low)
            windowStartNs = frameTimeNanos
            intervals = 0
            worstMs = 0f
        }
        choreographer.postFrameCallback(this)
    }
}
