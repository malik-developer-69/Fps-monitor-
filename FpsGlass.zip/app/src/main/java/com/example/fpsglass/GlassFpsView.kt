package com.example.fpsglass

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View

/**
 * Frosted-glass FPS card drawn with a single custom View.
 * No allocations in onDraw; redraws only when new stats arrive.
 */
class GlassFpsView(context: Context) : View(context) {

    private val d = resources.displayMetrics.density
    private val historySize = 30
    private val history = FloatArray(historySize)
    private var count = 0
    private var head = 0

    private var fps = 0
    private var refreshRate = 60f
    private var fpsText = "--"
    private var msText = "-- ms"
    private var lowText = "1% low --"

    private val card = RectF()
    private val radius = 22f * d
    private val pad = 12f * d

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * d
    }
    private val glossPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fpsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 30f * d
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 10f * d
        color = Color.argb(170, 255, 255, 255)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        letterSpacing = 0.12f
    }
    private val statPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 11f * d
        color = Color.argb(215, 255, 255, 255)
        textAlign = Paint.Align.RIGHT
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.8f * d
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val areaPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePath = Path()
    private val areaPath = Path()

    fun setRefreshRate(hz: Float) {
        refreshRate = hz.coerceAtLeast(30f)
    }

    fun update(newFps: Int, frameMs: Float, onePercentLow: Int) {
        fps = newFps
        history[head] = newFps.toFloat()
        head = (head + 1) % historySize
        if (count < historySize) count++
        fpsText = newFps.toString()
        msText = String.format("%.1f ms", frameMs)
        lowText = "1% low $onePercentLow"
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((158f * d).toInt(), (92f * d).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val inset = borderPaint.strokeWidth / 2f
        card.set(inset, inset, w - inset, h - inset)

        // Frosted body: brighter at the top, fading to a faint tint.
        fillPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.argb(70, 255, 255, 255), Color.argb(22, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
        // Specular rim light: strong top-left, nearly gone bottom-right.
        borderPaint.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            Color.argb(190, 255, 255, 255), Color.argb(25, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
        // Soft gloss highlight across the upper half.
        glossPaint.shader = LinearGradient(
            0f, 0f, 0f, h * 0.5f,
            Color.argb(45, 255, 255, 255), Color.argb(0, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        c.drawRoundRect(card, radius, radius, fillPaint)
        c.drawRoundRect(card, radius, radius, glossPaint)
        c.drawRoundRect(card, radius, radius, borderPaint)

        val accent = accentColor()

        // Big FPS number + label
        fpsPaint.color = accent
        val baseY = 40f * d
        c.drawText(fpsText, pad, baseY, fpsPaint)
        c.drawText("FPS", pad + fpsPaint.measureText(fpsText) + 5f * d, baseY, labelPaint)

        // Right-aligned stats
        val right = width - pad
        c.drawText(msText, right, 21f * d, statPaint)
        c.drawText(lowText, right, 37f * d, statPaint)

        drawSparkline(c, accent)
    }

    private fun drawSparkline(c: Canvas, accent: Int) {
        if (count < 2) return
        val left = pad
        val right = width - pad
        val top = 50f * d
        val bottom = height - pad
        val cap = refreshRate
        val step = (right - left) / (historySize - 1)
        val startIdx = if (count < historySize) 0 else head

        linePath.rewind()
        areaPath.rewind()
        var x = right - step * (count - 1)
        for (i in 0 until count) {
            val v = history[(startIdx + i) % historySize].coerceIn(0f, cap)
            val y = bottom - (v / cap) * (bottom - top)
            if (i == 0) {
                linePath.moveTo(x, y)
                areaPath.moveTo(x, bottom)
                areaPath.lineTo(x, y)
            } else {
                linePath.lineTo(x, y)
                areaPath.lineTo(x, y)
            }
            x += step
        }
        areaPath.lineTo(right, bottom)
        areaPath.close()

        areaPaint.color = Color.argb(60, Color.red(accent), Color.green(accent), Color.blue(accent))
        linePaint.color = accent
        c.drawPath(areaPath, areaPaint)
        c.drawPath(linePath, linePaint)
    }

    private fun accentColor(): Int {
        val ratio = fps / refreshRate
        return when {
            ratio >= 0.9f -> 0xFF4ADE80.toInt() // green
            ratio >= 0.5f -> 0xFFFBBF24.toInt() // amber
            else -> 0xFFF87171.toInt()          // red
        }
    }
}
