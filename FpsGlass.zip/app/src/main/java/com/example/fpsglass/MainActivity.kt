package com.example.fpsglass

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var button: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density

        val root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(
                    Color.parseColor("#1E1B4B"),
                    Color.parseColor("#6D28D9"),
                    Color.parseColor("#0EA5E9")
                )
            )
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding((28 * d).toInt(), (32 * d).toInt(), (28 * d).toInt(), (32 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 28 * d
                setColor(Color.argb(46, 255, 255, 255))
                setStroke((1.2f * d).toInt(), Color.argb(110, 255, 255, 255))
            }
        }

        val title = TextView(this).apply {
            text = "FPS Glass"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        }
        val sub = TextView(this).apply {
            text = "A tiny floating frame-rate monitor.\nDrag it anywhere on screen."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.argb(200, 255, 255, 255))
            setPadding(0, (8 * d).toInt(), 0, (24 * d).toInt())
        }
        button = Button(this).apply {
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 40 * d
                setColor(Color.argb(70, 255, 255, 255))
                setStroke((1 * d).toInt(), Color.argb(150, 255, 255, 255))
            }
            setOnClickListener { toggle() }
        }

        card.addView(title)
        card.addView(sub)
        card.addView(button, LinearLayout.LayoutParams((220 * d).toInt(), (52 * d).toInt()))
        root.addView(
            card,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshButton()
    }

    private fun toggle() {
        if (FpsOverlayService.running) {
            startService(Intent(this, FpsOverlayService::class.java).setAction(FpsOverlayService.ACTION_STOP))
            button.postDelayed({ refreshButton() }, 200)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        startForegroundService(Intent(this, FpsOverlayService::class.java))
        button.postDelayed({ refreshButton() }, 300)
    }

    private fun refreshButton() {
        button.text = when {
            FpsOverlayService.running -> "Stop monitor"
            Settings.canDrawOverlays(this) -> "Start monitor"
            else -> "Grant overlay permission"
        }
    }
}
