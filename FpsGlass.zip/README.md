# FPS Glass
Floating glass-morphism FPS monitor for Android (Kotlin, no dependencies).
Build: `gradle assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk
